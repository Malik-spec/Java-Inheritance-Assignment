Inheritance Java
