class Rectangle{
	int length;
	int breadth;
	
	Rectangle(int l, int b) {
		length = l;
		breadth = b;
		
	}
	
	void printArea() {
		System.out.println("The Area is : "+ length*breadth);
	}
	
	void printPerimeter() {
		System.out.println("The Perimeter is : "+ (length+breadth));
	}
	

	
}
class Square extends Rectangle{
	
	Square(int s) {
		super(s, s);
		
	}

	
	
}

public class Q3 {

	public static void main(String[] args) {
		//Area and Perimeter of Rectangle of length 5 and breadth 7 
		Rectangle r = new Rectangle(5,7);
		r.printArea();
		r.printPerimeter();
		
		// Area and Perimeter of a Square of side 5
		Square sq = new Square(5);
		sq.printArea();
		sq.printPerimeter();
		
		



}
}
