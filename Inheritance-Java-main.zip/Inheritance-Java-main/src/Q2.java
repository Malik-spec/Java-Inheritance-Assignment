class Member{
	String name;
	int age;
	String phoneNumber;
	String address;
	double salary;
	
	void printSalary() {
		System.out.println(name +" has a salary of "+salary);
		
	}
	
}

class Employee extends Member{
	String specialization;
	String department;
	
}

class Manager extends Member{
	String specialization;
	String department;
	
}

public class Q2 {

	public static void main(String[] args) {
		// Object of Employee
		Employee e = new Employee();
		e.name = " Klinsmann Agyei ";
		e.age = 24;
		e.phoneNumber = "0204980856";
		e.address = " EB-0012-5823 ";
		e.salary = 2000;
		e.printSalary();
		
		
		// Object of Manager
		Manager m = new Manager();
		m.name = " Amalitech ";
		m.age = 5;
		m.phoneNumber = "0501619835";
		m.address = " WR-0009-1123 ";
		m.salary = 400000;
		m.printSalary();

	}

}
